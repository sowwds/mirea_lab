#include <WiFi.h>
#include <PubSubClient.h>
#include "DHTesp.h"

// ===== WiFi =====
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ===== MQTT =====
const char* mqtt_server = "broker.emqx.io";

// ===== Топики (с твоим шифром) =====
const char* topicTemp = "edu/iot26fs101247/esp32/temperature";
const char* topicHum  = "edu/iot26fs101247/esp32/humidity";

// ===== Объекты =====
WiFiClient espClient;
PubSubClient client(espClient);
DHTesp dht;

// ===== Пин датчика =====
const int DHT_PIN = 15;

// ===== Подключение к WiFi =====
void setup_wifi() {
  delay(10);
  Serial.println("Connecting to WiFi...");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected");
}

// ===== Подключение к MQTT =====
void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting to MQTT...");

    if (client.connect("ESP32Client_26fs102367")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 2 sec");
      delay(2000);
    }
  }
}

// ===== setup =====
void setup() {
  Serial.begin(115200);

  dht.setup(DHT_PIN, DHTesp::DHT22);

  setup_wifi();

  client.setServer(mqtt_server, 1883);
}

// ===== loop =====
void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  TempAndHumidity data = dht.getTempAndHumidity();

  float temp = data.temperature;
  float hum = data.humidity;

  // ===== Логи =====
  Serial.print("Temperature: ");
  Serial.println(temp);

  Serial.print("Humidity: ");
  Serial.println(hum);

  // ===== Отправка =====
  client.publish(topicTemp, String(temp).c_str());
  client.publish(topicHum, String(hum).c_str());

  delay(5000); // интервал (важно по методичке)
}
